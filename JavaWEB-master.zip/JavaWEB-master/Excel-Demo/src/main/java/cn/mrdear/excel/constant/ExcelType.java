package cn.mrdear.excel.constant;

/**
 * 定义excel格式
 * @author Niu Li
 * @since 2017/3/17
 */
public enum  ExcelType {
  XLS, XLSX;
}
