INSERT INTO user(username,password) VALUES ('张三','111111');
INSERT INTO user(username,password) VALUES ('李四','111111');
INSERT INTO user(username,password) VALUES ('王二','111111');