package com.haikong.util;

/**
 * 保存常量信息
 */
public class Constants {
    /**
     * 微信接入token ，用于验证微信接口
     */
    public static String TOKEN = "niuli123";

}
