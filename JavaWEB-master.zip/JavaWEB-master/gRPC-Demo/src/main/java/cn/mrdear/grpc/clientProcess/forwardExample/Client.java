package cn.mrdear.grpc.clientProcess.forwardExample;

/**
 * 主调用接口
 * @author Niu Li
 * @date 2017/2/4
 */
public abstract class Client {
    public abstract void start(String say);
}
