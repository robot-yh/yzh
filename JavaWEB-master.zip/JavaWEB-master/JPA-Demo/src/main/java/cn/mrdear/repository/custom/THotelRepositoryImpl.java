package cn.mrdear.repository.custom;

/**
 * @author Niu Li
 * @date 2017/1/7
 */
public class THotelRepositoryImpl {
}
